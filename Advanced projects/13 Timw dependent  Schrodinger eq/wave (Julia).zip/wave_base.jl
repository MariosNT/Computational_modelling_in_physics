import PyPlot as plt
using PyCall
@pyimport matplotlib.animation as anim
@pyimport matplotlib
using Plots
using FFTW


L = 16
M = L/2
hx = 0.1
ht = 0.001
N = 1 + floor(Int, L/hx)
Nh = floor(Int, N/2)
xs = [i*hx-M for i in 0:N-1]

V = [0 for x in xs]
# V = [x^2/2 for x in xs]
phi = [exp(-x^2/2)*exp(im*0*x) for x in xs]
# phi = [sin(3*pi*(x+M)/L) for x in xs]

periodic = false
# 1 - only wave function
# 2 - wave function and energies
# 3 - wave function and Fourier transform of wave function(momentum representation)
option = 2

function simpson(f, N, h)
    norm = sum([(f[i-1]+4*f[i]+f[i+1])/3 for i in 2:2:N])
    if N%2 == 0
        norm += (5*f[end]+6*f[end-1]-f[end-2])/12
    end
    return norm*h
end

function energy(phi)
    U = simpson(abs2.(phi).*V, N, hx)
    T = simpson(-1*conj.(phi).*[0; (phi[1:end-2] + phi[3:end] -2*phi[2:end-1])/(hx*hx*2); 0], N, hx)
    return real.([T, U])
end

steps = 0
function update(frame)
    global phi, steps
    steps += 10
    phi = sum([basis[i]*decomposition[i]*exp(-im*energies[i]*steps*ht) for i in 1:50])

    phiplotr.set_data(0:hx:L, real.(phi))
    phiploti.set_data(0:hx:L, imag.(phi))
    prb.set_data(0:hx:L, abs2.(phi))

    if option == 2
        en = energy(phi)
        popfirst!(energytab1)
        push!(energytab1, en[1])
        enplot1.set_ydata(energytab1)
        popfirst!(energytab2)
        push!(energytab2, en[2])
        enplot2.set_ydata(energytab2)
        popfirst!(energytab3)
        push!(energytab3, en[1]+en[2])
        enplot3.set_ydata(energytab3)
    elseif option == 3
        tmp = abs2.(fft(phi))
        fftphi.set_ydata([tmp[Nh+2:end]; tmp[1:Nh+1]])
    end

    return ()
end

phi .-= minimum(abs.(phi))
norm = sqrt(simpson(abs2.(phi), N, hx))
phi/=norm

basis = [[sin(n*pi*(x-M)/L)+0im for x in xs] for n in 1:50]
basis = [f/sqrt(simpson(abs2.(f), N, hx)) for f in basis]
energies = [(n*pi/L)^2/2 for n in 1:50]
decomposition = [simpson(f.*phi, N, hx) for f in basis]

if option == 1
    fig = plt.figure()
    ax = plt.subplot()
else
    fig, (ax, ax2) = plt.subplots(2,1)
end

ax.set_xlim((0,L))
ax.set_ylim((-0.5, 1))
ax.plot(0:hx:L, V/10, "k")[1]
phiplotr = ax.plot(0:hx:L, real.(phi))[1]
phiploti = ax.plot(0:hx:L, imag.(phi))[1]
prb = ax.plot(0:hx:L, abs2.(phi))[1]

if option == 2
    ax2.set_ylim((-0.1, sum(energy(phi))+0.1))
    en = energy(phi)
    energytab1 = [en[1] for _ in 1:500]
    energytab2 = [en[2] for _ in 1:500]
    energytab3 = [en[1]+en[2] for _ in 1:500]
    enplot1 = ax2.plot(LinRange(-10.0,0.0,500), energytab1)[1]
    enplot2 = ax2.plot(LinRange(-10.0,0.0,500), energytab2)[1]
    enplot3 = ax2.plot(LinRange(-10.0,0.0,500), energytab3)[1]
elseif option == 3
    ax2.set_xlim((-pi,pi))
    ax2.set_ylim((-10, 500))
    tmp = abs2.(fft(phi))
    lr = LinRange(0,2*pi,N+1)[1:end-1]
    fftphi = ax2.plot(lr.-lr[Nh+1], [tmp[Nh+2:end]; tmp[1:Nh+1]])[1]
end

ani = anim.FuncAnimation(fig, update, interval = 1)
plt.show()